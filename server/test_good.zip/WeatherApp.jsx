import { use, useEffect } from "react"

const WeatherApp = ({cityData}) => {
    useEffect(() => {
        document.title = "Weather App"
    }, [])

    useEffect(() => {
        console.log("City data updated:", cityData)
    }, [cityData])  

    const {tempreture_2m: temperature} = use("weather-data")
    return (
        <div>
            <h2>Weather Application</h2>
            {/* Additional weather app components and logic will go here */}
        </div>
    )   
}
export default WeatherApp