Todo-List

A Todo List is a simple app where you manage tasks.

👉 You can:

Add tasks
View tasks
Mark as done ✔️
Delete tasks ❌

👉 In code, tasks are usually stored in an array:

let todos = ["Learn JS", "Practice coding"];

👉 Basic idea:

Add → push()
Delete → splice()
Complete → update value

👉 Purpose:
Helps you learn arrays, functions, and DOM.